require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const Database = require('better-sqlite3');
const nodemailer = require('nodemailer');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 10) {
  console.error('Set ADMIN_PASSWORD (10+ characters) in .env');
  process.exit(1);
}

const db = new Database('enquiries.db');
db.exec(`CREATE TABLE IF NOT EXISTS enquiries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, phone TEXT NOT NULL, product TEXT,
  quantity TEXT, message TEXT,
  status TEXT NOT NULL DEFAULT 'new',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
)`);

const mailer = process.env.SMTP_HOST ? nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 465),
  secure: Number(process.env.SMTP_PORT || 465) === 465,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
}) : null;

const app = express();
app.set('trust proxy', 1);
app.use(helmet());
app.use(express.json({ limit: '20kb' }));

const origins = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use('/api', cors({ origin: origins.length ? origins : false }));

const clean = (v, max) => String(v || '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max);

// Public: submit an enquiry from the website form
app.post('/api/enquiries',
  rateLimit({ windowMs: 15 * 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false }),
  async (req, res) => {
    const b = req.body || {};
    if (b.website) return res.json({ ok: true }); // honeypot field: bots fill it, humans don't
    const name = clean(b.name, 100), phone = clean(b.phone, 20);
    if (!name || phone.replace(/\D/g, '').length < 10)
      return res.status(400).json({ ok: false, error: 'Name and a valid phone number are required.' });
    const row = { name, phone, product: clean(b.product, 80), quantity: clean(b.quantity, 40), message: clean(b.message, 1500) };
    const info = db.prepare(
      'INSERT INTO enquiries (name, phone, product, quantity, message) VALUES (@name,@phone,@product,@quantity,@message)'
    ).run(row);
    if (mailer && process.env.NOTIFY_TO) {
      mailer.sendMail({
        from: process.env.SMTP_USER, to: process.env.NOTIFY_TO,
        subject: `New enquiry #${info.lastInsertRowid}: ${row.product || 'General'}`,
        text: `Name: ${row.name}\nPhone: ${row.phone}\nProduct: ${row.product}\nQuantity: ${row.quantity}\n\n${row.message}`
      }).catch(e => console.error('Mail failed:', e.message));
    }
    res.json({ ok: true, id: info.lastInsertRowid });
  });

// Admin: HTTP Basic auth (use HTTPS in production)
function auth(req, res, next) {
  const [scheme, token] = (req.headers.authorization || '').split(' ');
  if (scheme === 'Basic' && token) {
    const [user, ...rest] = Buffer.from(token, 'base64').toString().split(':');
    const a = Buffer.from(rest.join(':')), b = Buffer.from(ADMIN_PASSWORD);
    if (user === 'admin' && a.length === b.length && crypto.timingSafeEqual(a, b)) return next();
  }
  res.set('WWW-Authenticate', 'Basic realm="Kaash admin"').status(401).send('Login required');
}
const adminLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 100 });

app.get('/api/admin/enquiries', adminLimiter, auth, (req, res) => {
  res.json(db.prepare('SELECT * FROM enquiries ORDER BY id DESC LIMIT 500').all());
});
app.patch('/api/admin/enquiries/:id', adminLimiter, auth, (req, res) => {
  const status = ['new', 'contacted', 'done'].includes(req.body.status) ? req.body.status : null;
  if (!status) return res.status(400).json({ error: 'Invalid status' });
  db.prepare('UPDATE enquiries SET status=? WHERE id=?').run(status, Number(req.params.id));
  res.json({ ok: true });
});
app.delete('/api/admin/enquiries/:id', adminLimiter, auth, (req, res) => {
  db.prepare('DELETE FROM enquiries WHERE id=?').run(Number(req.params.id));
  res.json({ ok: true });
});

// Admin inbox page
app.get('/admin', adminLimiter, auth, (req, res) => {
  res.set('Content-Security-Policy', "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'");
  res.type('html').send(`<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Enquiries</title><style>body{font:15px system-ui;max-width:900px;margin:20px auto;padding:0 14px}
.c{border:1px solid #ddd;padding:12px;margin:10px 0;border-radius:6px}.c.done{opacity:.55}button{margin-right:6px;padding:5px 10px}
.m{color:#555;margin:6px 0;white-space:pre-wrap}</style><h2>Enquiries</h2><div id=l>Loading…</div>
<script>
const l=document.getElementById('l');
async function load(){const r=await fetch('/api/admin/enquiries');const d=await r.json();l.textContent='';
if(!d.length){l.textContent='No enquiries yet.';return}
d.forEach(e=>{const c=document.createElement('div');c.className='c '+e.status;
const t=document.createElement('b');t.textContent='#'+e.id+' '+e.name+' · '+e.phone+' · '+(e.product||'')+(e.quantity?' · qty '+e.quantity:'')+' · '+e.created_at+' UTC · '+e.status;
const m=document.createElement('div');m.className='m';m.textContent=e.message||'';c.append(t,m);
[['contacted','Contacted'],['done','Done'],['new','Reopen']].forEach(([s,n])=>{const b=document.createElement('button');b.textContent=n;
b.onclick=async()=>{await fetch('/api/admin/enquiries/'+e.id,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status:s})});load()};c.append(b)});
const x=document.createElement('button');x.textContent='Delete';x.onclick=async()=>{if(confirm('Delete this enquiry?')){await fetch('/api/admin/enquiries/'+e.id,{method:'DELETE'});load()}};c.append(x);
l.append(c)})}
load();
</script>`);
});

app.get('/health', (req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log('Kaash backend running on port ' + PORT));
