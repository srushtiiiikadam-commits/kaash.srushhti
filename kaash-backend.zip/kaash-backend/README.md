# Kaash Enterprises / Srushhti Earthline: backend

Enquiry API + private admin inbox (Node.js, Express, SQLite).

## Run locally
1. Install Node.js 18+.
2. `cd kaash-backend && npm install`
3. `cp .env.example .env` and set `ADMIN_PASSWORD` (and SMTP settings if you want email alerts).
4. `npm start`
5. Open http://localhost:3000/admin (username `admin`, your password).

## API
- `POST /api/enquiries` (public, rate limited): JSON `{name, phone, product, quantity, message}`. Keep an empty hidden field named `website` in the form as a spam trap.
- `GET /api/admin/enquiries`, `PATCH /api/admin/enquiries/:id` (`{status: new|contacted|done}`), `DELETE /api/admin/enquiries/:id`: need admin login.

## Connect the website form
In the website's "Send Enquiry" handler, replace the built-in storage with:

    fetch('https://YOUR-API-DOMAIN/api/enquiries', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({name, phone, product, quantity, message})
    })

and set `ALLOWED_ORIGINS` to the website's address.

## Deploy
Any Node host works (Render, Railway, a VPS). Put it behind HTTPS (the admin login uses Basic auth), keep `.env` private, and back up `enquiries.db` regularly. On hosts with temporary disks, attach a persistent volume for the database file.
